#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import json
import urllib2
import mysql.connector
import datetime

def get_data(p_api_key,p_series_id,p_batch_id,p_realstart,p_realend):
	                         
		
	v_url = "https://api.stlouisfed.org/fred/series/observations?series_id="+p_series_id+"&realtime_start="+p_realstart+"&realtime_end="+p_realend+"&api_key="+p_api_key+"&file_type=json"
	#print(v_url)
	fred_response = urllib2.urlopen(v_url)
	parsed = json.loads(fred_response.read())
	#print json.dumps(parsed, indent=4, sort_keys=True)
	
	db = mysql.connector.connect(user='test123', password='test123',host='127.0.0.1',database='fred')
	cur = db.cursor()
	
	#print(len(parsed['observations']))
	
	for i in range(0,len(parsed['observations'])):
		#print(parsed['observations'][i])
		v_event_date = parsed['observations'][i][u'date']
		v_realtime_start = parsed['observations'][i][u'realtime_start']
		v_realtime_end = parsed['observations'][i][u'realtime_end']
		v_value = parsed['observations'][i][u'value']
		
		
		insertstmt=("insert into fred_observations (batch_id, series_id, event_date, realtime_start_dt,realtime_end_dt,value) values ('%s', '%s', '%s', '%s', '%s', '%s')" % (p_batch_id, p_series_id, v_event_date, v_realtime_start,v_realtime_end,v_value))
		try:
			cur.execute(insertstmt)	
		except Exception as e:
			print("Insertion Failed: "+str(e))	
		    
	db.commit()
	
	cur.close()	
		
	db.close()	

if __name__ == '__main__':	
	api_key = sys.argv[1]
	series_id = sys.argv[2]
	batch_id = sys.argv[3]
	
	if sys.argv[4] == 'N':
		realstart = datetime.date.today().strftime("%Y-%m-%d") #2013-08-14
	else:
		realstart = sys.argv[4]
			
	if sys.argv[5] == 'N':
		realend = datetime.date.today().strftime("%Y-%m-%d") #2013-08-14	
	else:
		realend = sys.argv[5]	
	
	#GDPC1 		= 'GDPC1'	
	#UMCSENT = 'UMCSENT'
	#UNRATE 	= 'UNRATE'
	
	
	get_data(api_key,series_id,batch_id,realstart,realend)

#python Data_Load_Json.py "1efaf0bfd42dcc91353952dd29e7aaee" "UNRATE" 1 "1961-02-01" "1961-02-01"

